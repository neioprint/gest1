
const nombredefoi = document.querySelector('nombredefois');

 console.log(nombredefoi); 